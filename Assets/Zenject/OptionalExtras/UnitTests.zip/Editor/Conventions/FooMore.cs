#if !(UNITY_WSA && ENABLE_DOTNET)

using System;

namespace Zenject.Tests.Convention.NamespaceTest
{
    public class Bar
    {
    }

    public class Foo4 : IFoo
    {
    }
}

#endif
